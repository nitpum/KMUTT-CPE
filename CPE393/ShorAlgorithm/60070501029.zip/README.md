# Implement Shor's algorithm 
60070501029 Nitipoom Unrrom

## Requirement
Node.js

```bash
node shor.js <number>
```